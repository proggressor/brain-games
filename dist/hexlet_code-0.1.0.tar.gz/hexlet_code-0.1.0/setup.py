# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Hexlet tests and linter status\n\n[![Actions Status](https://github.com/proggressor/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/proggressor/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/dc8739c8926326013bb3/maintainability)](https://codeclimate.com/github/proggressor/python-project-49/maintainability)\n\n**Examples of games**\n\n1. Is this number even?\n[![asciicast](https://asciinema.org/a/Tp2J0J4w5Sbf54S4E8R3KxEni.png)](https://asciinema.org/a/Tp2J0J4w5Sbf54S4E8R3KxEni)\n\n2. Calculator\n[![asciicast](https://asciinema.org/a/3CLetuRheC9e1phaMc7YFrSHP.png)](https://asciinema.org/a/3CLetuRheC9e1phaMc7YFrSHP)\n\n3. Greatest common divisor\n[![asciicast](https://asciinema.org/a/V1QhlHm4OR8zV7nHxpo0GGRFV.png)](https://asciinema.org/a/V1QhlHm4OR8zV7nHxpo0GGRFV)\n\n4. Progression\n[![asciicast](https://asciinema.org/a/uJ4NLCBY0C2JAuI7RKLEKlNCP.png)](https://asciinema.org/a/uJ4NLCBY0C2JAuI7RKLEKlNCP)\n',
    'author': 'Vorobyev',
    'author_email': 'nikos1997@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
