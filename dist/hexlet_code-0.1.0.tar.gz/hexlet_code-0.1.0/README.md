### Hexlet tests and linter status:
[![Actions Status](https://github.com/proggressor/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/proggressor/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/dc8739c8926326013bb3/maintainability)](https://codeclimate.com/github/proggressor/python-project-49/maintainability)

**Examples of games**

1. Is this number even?
[![asciicast](https://asciinema.org/a/Tp2J0J4w5Sbf54S4E8R3KxEni.png)](https://asciinema.org/a/Tp2J0J4w5Sbf54S4E8R3KxEni)
